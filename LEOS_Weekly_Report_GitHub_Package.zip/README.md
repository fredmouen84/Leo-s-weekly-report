
# LEO's Weekly Report App

A self-contained interactive dashboard developed by **Fred Mouen (LAZ Parking)** for internal business development visibility.

### 🔹 Features
- Import opportunities (TXT / pasted format)
- Save, Reset, and Clear reports locally
- Export to Word / Excel
- Editable cards with hover and expand effects
- Persistent data between sessions
- Mobile-friendly dark layout

### 🌐 Deploy on GitHub Pages
1. Create a **public repository** named `leos-weekly-report`.
2. Upload this folder’s contents (`index.html` and `README.md`) to the repo root.
3. Go to **Settings → Pages → Source** → choose `main` / `(root)` → Save.
4. Your app will be live at:  
   `https://<your-username>.github.io/leos-weekly-report/`

### 🧠 Notes
- All app data is stored in your browser (via localStorage).
- Works fully offline after first load.
- Built for LAZ Parking BD team by Fred Mouen.

---
© 2025 Fred Mouen. All rights reserved.
